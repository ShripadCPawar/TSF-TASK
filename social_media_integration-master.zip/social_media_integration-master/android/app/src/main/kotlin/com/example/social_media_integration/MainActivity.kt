package com.example.social_media_integration

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
